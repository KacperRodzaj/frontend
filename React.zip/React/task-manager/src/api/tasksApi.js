const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const fetchTasks = async () => {
  await delay(500); // Symulacja API
  try {
    const stored = localStorage.getItem('tasks');
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

export const saveTasks = async (tasks) => {
  await delay(300);
  localStorage.setItem('tasks', JSON.stringify(tasks));
};
